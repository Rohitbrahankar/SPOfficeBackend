package com.Backend.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Backend.Entities.Area;

public interface AreaRepository extends JpaRepository<Area, Long> {

}
